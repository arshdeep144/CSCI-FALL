//Author: Arshdeep Benipal
//Student ID: 100591622
//Date: October 17 2016
//Purpose: Lab 4  
import java.util.*;
public class SortedDoublyLinkedList<E> implements LinkedList{
	//creates front and end variales of a linked list
	Node header = null;
	Node trailer = null;

	//declares front and end variales of a linked list
	public SortedDoublyLinkedList(){
		this.header = null;
		this.trailer = null;
	}

	//inserts the warrior into the linked list
	public void insert(Warrior w){
		if (header == null){
			this.header = new Node(w);
			this.trailer = new Node(w);
		}
		else if (this.header == this.trailer){
			this.header.setNext(w);
			this.trailer = new Node (w);
		}
		else{
			this.trailer.setNext(w);
			Node t = this.trailer;
			this.trailer = new Node(w);
			this.trailer.setPrev(t.self);
		}
	}

	//prints the whole list
	public String toString(){
		if (this.header == null)
			return "Empty.";
		Node cNode = this.header;
		String listcontents = "";
		while (cNode.next != null){
			if(cNode == this.trailer)
				listcontents = listcontents + cNode.self.toString();
			else{
				listcontents = listcontents + cNode.self.toString() + " ";
				cNode.self = cNode.next;
			}
		}
		return listcontents;
	}
}