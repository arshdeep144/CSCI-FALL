//Author: Arshdeep Benipal
//Student ID: 100591622
//Date: October 17 2016
//Purpose: Lab 4  

public class Node{
	//creates previous, next, and self variables for node
	Warrior self;
	Warrior next = null;
	Warrior prev = null;

	//declares the self variable
	public Node (Warrior w){
		this.self = w;
	}

	//returns the next variable
	public Warrior getNext(){
		return this.next;
	}

	//returns the previous variable
	public Warrior getPrev(){
		return this.prev;
	}

	//sets teh next variable to a warrior
	public void setNext(Warrior w){
		this.next = w;
	}

	//sets the previous variable for warrior
	public void setPrev(Warrior w){
		this.prev = w;
	}
}