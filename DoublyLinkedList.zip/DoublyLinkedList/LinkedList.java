//Author: Arshdeep Benipal
//Student ID: 100591622
//Date: October 17 2016
//Purpose: Lab 4  
//creates an interface for SOrtedDoublyLinkedList
interface LinkedList{
	void insert(Warrior warrior);
	String toString();
}