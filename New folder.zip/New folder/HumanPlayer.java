import java.io.*;
import java.util.*;
import java.lang.Integer.*;
/**
*The humanplayer class creates the human with a monster
*
*@author	Arshdeep Benipal, Wesley Huang, Edmond Liu
*@since		2016-10-21
**/
public class HumanPlayer extends Player{

	InputStreamReader cin = null;	
	Monster _monster;
	/**
	* This constructs the players monster
	*@param Monster This takes in the monster data to be saved in the class
	**/
	public HumanPlayer(Monster monster){
		_monster = monster;
	}

	/**
	*This method is used to check if the player or
	*computor has lost
	*@return boolean This returns if the player or
	*comp has lost
	**/
	public boolean hasLost(){
		return (_monster.getHP() <= 0);
	}

	/**
	*This method is to determine if it is a crit
	*@return boolean tells you if the attack was a crit or not
	*
	**/
	public boolean isCrit(){
		int random = (int)(Math.random() * 16) + 1;
		if (random == 16)	{return true;}
		else	{return false;}
	}

	/**
	*This method is used retrieve te data of the monster
	*@return Monster This returns the data of the monster being used
	**/
	public Monster getMonster(){
		return this._monster;
	}

	/**
	*This method chooses the move based on user input
	*@return int This returns the move needed to be used
	**/
	public int chooseMove(){

		int move;
		try{
			cin = new InputStreamReader(System.in);
			_monster.moveToString();
			System.out.printf("Enter number 1-4 for move:");
			move = cin.read();
		}
		catch(IOException e){
			move = 1;
		}
		return move;
	}

	/**
	*This method checks which monster is faster
	*@param enemy This is all the data of the opposing moster
	*@return boolean Returns whether or not your monster is faster
	**/
	public boolean isFasterThan(Player enemy){
		if(this._monster.getSpeed() > enemy.getMonster().getSpeed())
			return true;
		else if(this._monster.getSpeed() == enemy.getMonster().getSpeed()){
			int rand = (int)(Math.random()* 2 + 1);
			if (rand==1)
				return true;
			else
				return false;
 		}
		else {
			return false;
		}
	}

	/**
	*This method is to determine if your attack is supereffective or
	*not very effective
	* @param Player the opponents monsters data
	*@param Move the move being used
	*@return double the multiplication factor that will happen to your attack
	**/
	public double elementalDamage(Player player,Move move){
		double multiplier = 1;
		Monster playerMonster = player.getMonster();
		System.out.println(playerMonster.getType() + " " + move.getMoveType());
		if(playerMonster.getType() == "Grass"){
			if (move.getMoveType() == "Fire"){
				multiplier = 2;
			}
			else if(move.getMoveType() == "Flying"){
				multiplier = 0.5;
			}
		}	
		else if(playerMonster.getType() == "Fire"){
			if (move.getMoveType() == "Normal"){
				multiplier = 2;
			}
			else if(move.getMoveType() == "Grass"){
				multiplier = 0.5;
			}
		}
		else if(playerMonster.getType() == "Normal"){
			if (move.getMoveType() == "Flying"){
				multiplier = 2;
			}
			else if(move.getMoveType() == "Fire"){
				multiplier = 0.5;
			}
		}
		else if(playerMonster.getType() == "Flying"){
			if (move.getMoveType() == "Grass"){
				multiplier = 2;
			}
			else if(move.getMoveType() == "Normal"){
				multiplier = 0.5;
			}
		}
		else{
			multiplier = 1;
		}
		return multiplier;
	}

	/**
	*This method changes the hp based on how much damage the given attack does
	*based upon the attack of the monster, move power, and the enemy monster's
	*defense
	*@param player This is all the data on the opposing monster
	*@param move	This is the move that is wanted to be used
	*@return nothing
	**/

	public void attack(Player player, int move){
		boolean crit = this.isCrit();
		if (crit){
			Move usedMove = this.getMonster().returnMove(move);
			int damageDealt = this.getMonster().getAttack() +
								usedMove.getMovePower() - 
								player.getMonster().getDefense();
			damageDealt = (int)(damageDealt * 1.8 * this.elementalDamage(player, usedMove));
			player.getMonster()._hp = player.getMonster().getHP() - damageDealt;
			System.out.println("CRITICAL HIT! You dealt " + damageDealt + " damage with " + usedMove.getMoveName());
		}
		else{
			Move usedMove = this.getMonster().returnMove(move);
			int damageDealt = (this.getMonster().getAttack() +
								usedMove.getMovePower() - 
								player.getMonster().getDefense());
			damageDealt = (int)(damageDealt * this.elementalDamage(player,usedMove));
			player.getMonster()._hp = player.getMonster().getHP() - damageDealt;
			System.out.println("You dealt " + damageDealt + " damage with " + usedMove.getMoveName());
		}
	}
}