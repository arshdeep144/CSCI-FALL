/**
*This class stores the data of each and every move
*
*@author	Arshdeep Benipal, Wesley Huang, Edmond Liu
*@since		2016-10-21
**/
public class Move{
	public String _name;
	public String _type;
	public int _power;
	public float _accuracy;
	/**
	*This stores the data of the move int various varirable
	*
	*@param String name of the move
	*@param String the type of move it is
	*@param int the power of the move
	*@param float the accuracy of the move
	**/
	public Move(String name, String type, int power, float accuracy){
		this._name = name;
		this._type = type;
		this._power = power;
		this._accuracy = accuracy;
	}

	/**
	*This method determines if the move hits or not
	*
	*@return boolean tells you if the move will hit the other monster or not
	**/
	public boolean willHit(){
		float random = (float)(Math.random());
		if (_accuracy == 1.0){
			return true;
		}
		else if(_accuracy > random){
			return true;
		}
		else{
			return false;
		}
	}

	/**
	* This method gets the moves name
	*@return String the name of the move
	**/
	public String getMoveName(){
		return this._name;
	}

	/**
	* This method gets the moves type
	*@return String the type of the move
	**/
	public String getMoveType(){
		return this._type;
	}

	/**
	* This method gets the moves power
	*@return int the power of the move
	**/
	public int getMovePower(){
		return this._power;
	}

	/**
	* This method gets the moves accuracy
	*@return float the accuracy of the move
	**/
	public float getMoveAccuracy(){
		return this._accuracy;
	}

}