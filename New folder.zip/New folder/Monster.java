import java.lang.Math.*;
/**
*The montser class stores all the data for the monster
*
*@author	Arshdeep Benipal, Wesley Huang, Edmond Liu
*@since		2016-10-21
**/
public class Monster{
	public String _name;
	public String _type;
	public int _hp;
	public int _speed;
	public int _attack;
	public int _defense;
	public Move _move1;
	public Move _move2;
	public Move _move3;
	public Move _move4;

	/**
	*This method stores the data
	*
	*@param String the name of the monster
	*@param String the type of the monster
	*@param int the hp of the monster
	*@param int the speed of the monster
	*@param int the attacking power of the monster
	*@param int the defence power of the monster
	*@param Move the first move of the monster
	*@param Move the second move of the monster
	*@param Move the third move of the monster
	*@param Move the fourth move of the monster
	**/
	public Monster(String name, String type, int hp, int speed, int attack,
						int defense, Move move1, Move move2, Move move3, Move move4){
		this._name = name;
		this._type = type;
		this._hp = hp;
		this._speed = speed;
		this._attack = attack;
		this._defense = defense;
		this._move1 = move1;
		this._move2 = move2;
		this._move3 = move3;
		this._move4 = move4;
	}

	/**
	*This method returns the move being used by the monster
	*@param int the number from 1-4 for wihich move to use
	*@return Move returns the move based on the nuber in the parameters
	**/
	public Move returnMove(int move){
		if(move == 1)
			return _move1;
		else if(move == 2)
			return _move2;
		else if (move == 3)
			return _move3;
		else
			return _move4;
	}

	/**
	* This method prints al the moves of the monster
	* @return void nothing
	**/
	public void moveToString(){
		int count = 1;
		while (count < 5){
			System.out.println("Move " + (count) + ": " + returnMove(count).getMoveName() + ", Attack Power: "
								+ returnMove(count).getMovePower());
			count++;
		}
	}

	/**
	* This method returns the name
	*@return String returns the name
	**/
	public String getName(){
		return this._name;
	}

	/**
	* This method returns the type of the monster
	*@return String returns the type of the monster
	**/
	public String getType(){
		return this._type;
	}

	/**
	* This method returns the hp
	*@return int returns the hp
	**/
	public int getHP(){
		return this._hp;
	}

	/**
	* This method returns the speed
	*@return int returns the speed
	**/
	public int getSpeed(){
		return this._speed;
	}

	/**
	* This method returns the attackpower
	*@return int returns the attackpower
	**/
	public int getAttack(){
		return this._attack;
	}

	/**
	* This method returns the defense
	*@return int returns the defense
	**/
	public int getDefense(){
		return this._defense;
	}

}