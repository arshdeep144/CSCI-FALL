import java.lang.Math.*;
import java.io.*;
import java.util.*;
/**
*The player class is an abstract class that
*is guidelines for the cpu and human
*
*@author	Arshdeep Benipal, Wesley Huang, Edmond Liu
*@since		2016-10-21
**/
public abstract class Player{

	/**
	*This method is used to check if the player or
	*computor has lost
	*@return boolean This returns if the player or
	*comp has lost
	**/
	public abstract boolean hasLost();

	/**
	*This method is to determine if it is a crit
	*@return boolean tells you if the attack was a crit or not
	*
	**/
	public abstract boolean isCrit();
	/**
	*This method is used retrieve te data of the monster
	*@return Monster This returns the data of the monster being used
	**/
	public abstract Monster getMonster();

	/**
	*This method chooses the move
	*@return int This returns the move needed to be used
	**/
	public abstract int chooseMove () ;

	/**
	*This method checks which monster is faster
	*@param enemy This is all the data of the opposing moster
	*@return boolean Returns whether or not your monster is faster
	**/
	public abstract boolean isFasterThan(Player enemy);

	/**
	*This method is to determine if your attack is supereffective or
	*not very effective
	* @param Player the opponents monsters data
	*@param Move the move being used
	*@return double the multiplication factor that will happen to your attack
	**/
	public double elementalDamage(Player player,Move move);

	/**
	*This method changes the hp based on how much damage the given attack does
	*based upon the attack of the monster, move power, and the enemy monster's
	*defense
	*@param player This is all the data on the opposing monster
	*@param move	This is the move that is wanted to be used
	*@return nothing
	**/
	public abstract void attack(Player player, int move);
}