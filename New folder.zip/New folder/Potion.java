public class Potion{
	private int _potStrength;
	public int _remainingUses;

	public Potion(){
		_potStrength = 25;
		_remainingUses = 2;
	}

	public void description(){
		System.out.println("A potion that will heal " + _potStrength + "Health. Contains " + this.remainingUsage() + " usages.");
	}
	public int remainingUsage(){
		return this._remainingUses;
	}

}